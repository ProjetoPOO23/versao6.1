package Classes;

public class Comissao {
    
    private int cod_P;
    private double custoComissão;
    
}
